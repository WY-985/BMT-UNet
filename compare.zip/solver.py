﻿import warnings
import time
import torchvision
import torch.nn as nn
from torch import optim
import os
import numpy as np

from helpers.metrics.Tversky_loss import TverskyLoss
from helpers.networks.share import init_weights
from helpers.metrics.evaluation import *
from helpers.record.logger import Logger
from helpers.record.summaries import TensorboardSummary
from helpers.networks.SegNet import SegNet
from helpers.metrics.dice_loss import DiceLoss
from helpers.metrics.focal_loss import FocalLoss
warnings.filterwarnings('ignore')


class Solver(object):
    def __init__(self, c, train_loader, valid_loader, test_loader):
        """For summary"""
        self.summary = TensorboardSummary(c.log_dir)
        self.writer = self.summary.create_summary()
        self.pw = Logger(c.log_txt)

        """For Train"""
        self.GPU_id = c.GPU_id
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu', self.GPU_id[0])
        self.model_type = c.model_type
        self.model = None
        self.model_path = c.model_path
        self.result_path = c.result_path
        self.gt_path = c.gt_path
        self.optimizer = None

        self.criterion = c.criterion

        self.epochs = c.epochs
        self.decay = c.decay
        self.lr = c.lr
        self.beta1 = c.beta1
        self.beta2 = c.beta2
        self.t = c.t
        """For data loader"""
        self.train_loader =train_loader
        self.valid_loader = valid_loader
        self.test_loader = test_loader
        self.best = 0
        self.multi_gpu = 0
        self.focalLoss_a = c.focalLoss_a
        self.build(c)

    def build(self,c):
        if self.criterion == 'tversky_loss':
            self.criterion = TverskyLoss()
        if self.criterion == 'bce':
            self.criterion = nn.BCELoss()
        if self.criterion == 'DiceLoss':
            self.criterion = DiceLoss()
        if self.criterion == 'focal':
            self.criterion = FocalLoss(gamma=2, alpha=self.focalLoss_a, reduction='elementwise_mean')
        if self.model_type == 'SegNet':
            # self.model = SegNet(img_ch=1, output_ch=1)
            self.model = SegNet()

        if len(self.GPU_id) > 1:
            self.multi_gpu = 1

        if c.checkpoint is not None:
            self.model.load_state_dict(torch.load(c.checkpoint))
        else:
            init_weights(self.model)

        if self.multi_gpu:
            self.model = nn.DataParallel(self.model, device_ids=self.GPU_id)

        self.optimizer = optim.Adam(list(self.model.parameters()), self.lr, [self.beta1, self.beta2])
        if self.multi_gpu:
            self.optimizer = nn.DataParallel(self.optimizer, device_ids=self.GPU_id)
        self.model.to(self.device)
        self.pw.write('Using {} '.format(self.model_type))
    def train(self):
        lr = self.lr
        self.model_path = os.path.join(self.model_path, '%s-%d-lr%.4f' % (self.model_type, self.epochs, self.lr))

        beginning = time.strftime('%Y-%m-%d-%H-%M',time.localtime(time.time()))
        self.pw.write(beginning)

        for epoch in range(self.epochs):
            self.model.train(True)
            epoch_loss = 0
            acc, SE, SRe, SP, PC, SPr, F1, JS, DC, length = 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.
            num_img = len(self.train_loader)
            for i, (im, gt) in enumerate(self.train_loader):
                """Loading data"""
                im = im.to(self.device)
                gt = gt.to(self.device)
                sr = torch.sigmoid(self.model(im))
                """Cal loss"""
                loss = self.criterion(sr, gt)
                epoch_loss += loss.item()
                self.writer.add_scalar('train/total_loss_iter', loss.item(), i + num_img * epoch)

                """Back propagation"""
                self.model.zero_grad()
                loss.backward()
                if self.multi_gpu:
                    self.optimizer.module.step()
                else:
                    self.optimizer.step()
                '''Evaluation'''
                for j, (pred, true) in enumerate(zip(sr, gt)):
                    acc += get_accuracy(pred, true)
                    SE += get_sensitivity(pred, true)
                    SRe += get_skeleton_recall(pred, true, self.device)
                    SP += get_specificity(pred, true)
                    PC += get_precision(pred, true)
                    SPr += get_skeleton_precision(pred, true, self.device)
                    F1 += get_F1(pred, true)
                    JS += get_JS(pred, true)
                    DC += get_DC(pred, true)
                length += im.size(0)

            acc, SE, SRe, SP, PC, SPr, F1, JS, DC = acc / length, SE / length, SRe / length, SP / length, PC / length, SPr / length, F1 / length, JS / length, DC / length
            out = '\nEpoch [%d/%d], Loss: %.4f, \n' \
                  '[Training] Acc: %.4f, SE: %.4f, SRe: %.4f, SP: %.4f, PC: %.4f, SPr: %.4f, F1: %.4f, JS: %.4f, DC: %.4f\n' \
                  % (epoch + 1, self.epochs, epoch_loss, acc, SE, SRe, SP, PC, SPr, F1, JS, DC)
            self.pw.write(out)

            if (epoch + 1) > (self.epochs - self.decay):
                lr -= (self.lr / float(self.decay))
                if self.multi_gpu:
                    for param_group in self.optimizer.module.param_groups:
                        param_group['lr'] = lr
                else:
                    for param_group in self.optimizer.param_groups:
                        param_group['lr'] = lr
                out = 'Decay learning rate to lr: {}.\n'.format(lr)
                self.pw.write(out)
            self.writer.add_scalar('train/total_loss_epoch', epoch_loss, epoch)
            self.valid(epoch)
        self.writer.close()

    def valid(self, epoch):
        self.model.train(False)
        self.model.eval()
        acc, SE, SRe, SP, PC, SPr, F1, JS, DC, length = 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.
        for i, (im, gt) in enumerate(self.valid_loader):
            im = im.to(self.device)
            gt = gt.to(self.device)
            sr = torch.sigmoid(self.model(im))
            for j, (pred, true) in enumerate(zip(sr, gt)):
                acc += get_accuracy(pred, true)
                SE += get_sensitivity(pred, true)
                SRe += get_skeleton_recall(pred, true, self.device)
                SP += get_specificity(pred, true)
                PC += get_precision(pred, true)
                SPr += get_skeleton_precision(pred, true, self.device)
                F1 += get_F1(pred, true)
                JS += get_JS(pred, true)
                DC += get_DC(pred, true)
            length += im.size(0)
        acc, SE, SRe, SP, PC, SPr, F1, JS, DC = acc / length, SE / length, SRe / length, SP / length, PC / length, SPr / length, F1 / length, JS / length, DC / length
        out = '[Validation] Acc: %.4f, SE: %.4f, SRe: %.4f, SP: %.4f, PC: %.4f, SPr: %.4f, F1: %.4f, JS: %.4f, \033[34m DC: %.4f\033[0m\n' % (
            acc, SE, SRe, SP, PC, SPr, F1, JS, DC)
        self.pw.write(out)

        if DC > self.best:
            self.best = DC
            best_model = self.model.state_dict()
            self.pw.write('\033[1;31;0m Best %s model score : %.4f \033[0m\n' % (self.model_type, self.best))
            torch.save(best_model, self.model_path)
        self.writer.add_scalar('val/acc', acc, epoch)
        self.writer.add_scalar('val/SE', SE, epoch)
        self.writer.add_scalar('val/SRe', SRe, epoch)
        self.writer.add_scalar('val/SP', SP, epoch)
        self.writer.add_scalar('val/PC', PC, epoch)
        self.writer.add_scalar('val/SPr', SPr, epoch)
        self.writer.add_scalar('val/F1', F1, epoch)
        self.writer.add_scalar('val/JS', JS, epoch)
        self.writer.add_scalar('val/DC', DC, epoch)

    def test(self):
        self.model.train(False)
        self.model.eval()
        self.model.load_state_dict(torch.load(self.model_path))
        acc, SE, SRe, SP, PC, SPr, F1, JS, DC, length = 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.
        pic_name = 0
        for i, (im, gt) in enumerate(self.test_loader):
            im = im.to(self.device)
            gt = gt.to(self.device)
            sr = torch.sigmoid(self.model(im))
            for j, (pred, true) in enumerate(zip(sr, gt)):
                acc += get_accuracy(pred, true)
                SE += get_sensitivity(pred, true)
                SRe += get_skeleton_recall(pred, true, self.device)
                SP += get_specificity(pred, true)
                PC += get_precision(pred, true)
                SPr += get_skeleton_precision(pred, true, self.device)
                F1 += get_F1(pred, true)
                JS += get_JS(pred, true)
                DC += get_DC(pred, true)
                pred = pred > 0.5
                gt_paths = self.test_loader.dataset.gt_paths[i]
                #gt_save = self.result_path[:-6]+'/divid/'+gt_paths.split("/")[-2]
                #pre_save = self.result_path[:-6]+'/divid/' + gt_paths.split("/")[-2][:-5] + 'pre'
                #Linux用下面的这个，原因是windows是‘\\’，而linux是‘/’。
                gt_save = self.result_path[:-6]+'/divid/'+gt_paths.split("/")[-3]+'/'+gt_paths.split("/")[-2]
                pre_save = self.result_path[:-6]+'/divid/' + gt_paths.split("/")[-3]+'/'+gt_paths.split("/")[-2][:-5] + 'pre'
                if not os.path.exists(gt_save):
                    os.makedirs(gt_save)
                if not os.path.exists(pre_save):
                    os.makedirs(pre_save)
                torchvision.utils.save_image(true.data.cpu(), os.path.join(gt_save,gt_paths.split("/")[-1]))
                torchvision.utils.save_image(pred.float().data.cpu(), os.path.join(pre_save,gt_paths.split("/")[-1][:-7]+'.png'))
                torchvision.utils.save_image(true.data.cpu(), os.path.join(self.gt_path, '%d_gt.png' % pic_name))
                torchvision.utils.save_image(pred.float().data.cpu(), os.path.join(self.result_path, '%d.png' % pic_name))
                pic_name += 1
            length += im.size(0)
        acc, SE, SRe, SP, PC, SPr, F1, JS, DC = acc / length, SE / length, SRe / length, SP / length, PC / length, SPr / length, F1 / length, JS / length, DC / length
        out = '[Test] Acc: %.4f, SE: %.4f, SRe: %.4f, SP: %.4f, PC: %.4f, SPr: %.4f, F1: %.4f, JS: %.4f, \033[34m DC: %.4f\033[0m\n' % (
            acc, SE, SRe, SP, PC, SPr, F1, JS, DC)
        self.pw.write(out)

        endding = time.strftime('%Y-%m-%d-%H-%M', time.localtime(time.time()))
        self.pw.write(endding)
